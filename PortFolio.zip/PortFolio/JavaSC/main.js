//Función para validar el formulario antes de enviarlo
function validarFormulario(event) {
  event.preventDefault(); // Evita que el formulario se envíe automáticamente

// Obtener los valores ingresados por el usuario
const nombre = document.getElementById('nombre').value.trim();
const email = document.getElementById('email').value.trim();

// Validar que los campos obligatorios no estén vacíos
if (nombre === '' || email === '') {
    alert('Por favor, completa todos los campos obligatorios.');
    return;
}

// Si todo está bien, enviar el formulario
document.getElementById('contact-form').submit();
}

// Agregar un evento al formulario para llamar a la función validarFormulario cuando se envíe
document.getElementById('contact-form').addEventListener('submit', validarFormulario);